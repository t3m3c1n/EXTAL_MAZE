# Maze Horror

A top-down maze game made with Python and pygame. Your flashlight is your only
view of the maze. Collect stars, avoid two monsters, and hide in the vents when
things get too close.

**Play in the browser:** https://YOUR-USERNAME.itch.io/YOUR-GAME

## Controls

| Key / Mouse | Action |
|---|---|
| Mouse | Move (the player follows the cursor) |
| E | Hide in a vent / come out of hiding |
| SPACE | Return to the menu |
| ENTER | Start from the menu |

## Run locally

Requires Python 3.10+.

```bash
pip install pygame
python main.py
```

## Build for the web

The browser version is built with [pygbag](https://pypi.org/project/pygbag/).

```bash
pip install pygbag
pygbag --build .
```

The output goes to `build/web/`. To test it locally, run `pygbag .` and open
http://localhost:8000.

## Project layout

```
main.py                 game code
*.png, *.ogg            sprites and sound effects (loaded relative to main.py)
.github/workflows/      automatic web build and itch.io deploy
```

## Credits

Add your credits here (art, sound, and anything else you used).

## License

Add a license here if you want one (for example MIT).

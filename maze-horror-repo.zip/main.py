import asyncio
import math
import os
import random
import sys
import time
from collections import deque

import pygame

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()

BASE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else "."
IS_WEB = sys.platform == "emscripten"   # True when running in the browser
WIDTH, HEIGHT = 960, 720
FPS = 60
TILE = 48
PLAYER_SIZE = 30
FOLLOW_SPEED = 5
MAX_SPEED = 200
VISION_RADIUS = 195
RAY_COUNT = 180
RAY_STEP = 6
DANGER_RANGE = SHAKE_RANGE = 6 * TILE
MAX_SHAKE = 5
MONSTER_A_SPEED = MAX_SPEED * 0.5
MONSTER_B_SPEED = MAX_SPEED * 1.55 / 1.5
RUSH_MULT = 1.5
RUSH_END_RATIO = 0.5
KILLER_DIG_SPEED = 90
KILLER_RADIUS = 20
CATCH_DISTANCE = 30
DIG_REACH = 1.5 * TILE
DIG_MIN_PATH = 4
DIG_COOLDOWN = 3.0
BURROW_TIME = 0.7
EMERGE_TIME = 0.4
MARK_LIFETIME = 3.0
START_GRACE = 2.0
RESPAWN_GRACE = 1.0
SAFE_RESPAWN = 8 * TILE
STAR_COUNT = 8
STAR_RADIUS = 11
COLLECT_DISTANCE = 26
PLAYER_SCALE = 1.0
KILLER_SCALE = 1.15
ANIM_FPS = 8
DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))
CENTER = pygame.Vector2(WIDTH / 2, HEIGHT / 2)

RED = (220, 20, 20)
DIRT = (120, 78, 36)
DIRT_DARK = (70, 44, 20)
FLOOR = (30, 30, 30)
STAR_COLOR = (255, 225, 60)
VENT_FRAME = (110, 110, 120)
VENT_BODY = (60, 60, 65)
VENT_SLOT = (20, 20, 22)

# Map layout (from maze.png): '#' = wall, '.' = floor, 'V' = vent (fence tile)
MAP = [
    "####################",
    "#...#......#.....#V#",
    "#.#.####.#######.#.#",
    "#.#V.....#.....#...#",
    "#.#.###.#####.##.#.#",
    "#....#......#....#.#",
    "#.#.#######.#.######",
    "#V#...#...#V....#..#",
    "#V#####.#.#.##.##.##",
    "#...#...#####.....##",
    "###.#.#.#.#.#.###..#",
    "#.....#...#...#.##.#",
    "#####V###.#####.#..#",
    "#...#V#.#.#.#...#.##",
    "#.#.....#...#.###V##",
    "#.#######.###...#V##",
    "#....#....#...#....#",
    "####################",
]

# Star arrow
ARROW_RADIUS = 70     # distance from the player (screen pixels)
ARROW_SIZE = 12       # half-width of the arrow head
ARROW_COLOR = STAR_COLOR

# Sound
CLOSE_MIN_VOL = 0.35   # monster-close sound volume when the monster is at the edge of your vision

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Maze Horror")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 32)
big_font = pygame.font.SysFont(None, 64)
title_font = pygame.font.SysFont(None, 120)
world = pygame.Surface((WIDTH, HEIGHT))
darkness = pygame.Surface((WIDTH, HEIGHT))
darkness.set_colorkey((255, 0, 255))


def load_frames(name, count, scale, fallback):
    try:
        sheet = pygame.image.load(os.path.join(BASE, name)).convert_alpha()
        fw, fh = sheet.get_width() // count, sheet.get_height()
        size = (round(fw * scale), round(fh * scale))
        return [pygame.transform.scale(sheet.subsurface((i * fw, 0, fw, fh)), size) for i in range(count)]
    except (FileNotFoundError, pygame.error):
        s = pygame.Surface((30, 30), pygame.SRCALPHA)
        pygame.draw.circle(s, fallback, (15, 15), 15)
        return [s] * count


def tinted(frames, color):
    out = []
    for f in frames:
        g = f.copy()
        g.fill(color, special_flags=pygame.BLEND_RGB_ADD)
        out.append(g)
    return out


def load_wall():
    try:
        return pygame.transform.scale(pygame.image.load(os.path.join(BASE, "wall.png")).convert_alpha(), (TILE, TILE))
    except (FileNotFoundError, pygame.error):
        s = pygame.Surface((TILE, TILE))
        s.fill((70, 70, 90))
        pygame.draw.rect(s, (40, 40, 55), s.get_rect(), 2)
        return s


wall_img = load_wall()
PLAYER_FRAMES = load_frames("player.png", 4, PLAYER_SCALE, (0, 200, 255))
MONSTER_A_FRAMES = load_frames("killer.png", 4, KILLER_SCALE, RED)
MONSTER_B_FRAMES = tinted(MONSTER_A_FRAMES, (110, 0, 0))


def load_sound(name, volume=1.0):
    try:
        snd = pygame.mixer.Sound(os.path.join(BASE, name))
        snd.set_volume(volume)
        return snd
    except (FileNotFoundError, pygame.error):
        return None


def play_sound(snd):
    if snd:
        snd.play()


def start_loop(channel, snd, volume, fade_ms):
    if channel and snd:
        channel.play(snd, loops=-1, fade_ms=fade_ms)
        channel.set_volume(volume)


def set_loop_volume(channel, volume):
    if channel:
        channel.set_volume(volume)


def stop_loop(channel, fade_ms):
    if channel:
        channel.fadeout(fade_ms)


try:
    pygame.mixer.set_num_channels(16)
    pygame.mixer.set_reserved(1)  # channel 0 is kept for the looping monster-close sound
    CH_CLOSE = pygame.mixer.Channel(0)
except pygame.error:
    CH_CLOSE = None

SND_RESPAWN = load_sound("sfx_respawn.ogg", 0.8)
SND_STAR = load_sound("sfx_star.ogg", 0.6)
SND_VENT = load_sound("sfx_vent.ogg", 0.8)
SND_CLOSE = load_sound("sfx_monster_close.ogg", 0.8)


def make_light_falloff(radius):
    size = radius * 2 + 2
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    for r in range(radius, 0, -1):
        pygame.draw.circle(surf, (0, 0, 0, int(255 * (r / radius) ** 2.2)), (size // 2, size // 2), r)
    return surf


def make_danger_vignette():
    surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    cx, cy = WIDTH // 2, HEIGHT // 2
    outer = int(math.hypot(cx, cy))
    inner = int(outer * 0.45)
    for r in range(outer, 0, -4):
        t = max(0.0, (r - inner) / (outer - inner))
        pygame.draw.circle(surf, (190, 0, 0, int(200 * t * t)), (cx, cy), r)
    return surf


light_falloff = make_light_falloff(VISION_RADIUS)
danger_vignette = make_danger_vignette()


def draw_vent(surface, x, y):
    rect = pygame.Rect(x + 4, y + 4, TILE - 8, TILE - 8)
    pygame.draw.rect(surface, VENT_BODY, rect)
    for i in range(1, 4):
        yy = rect.top + i * rect.height // 4
        pygame.draw.line(surface, VENT_SLOT, (rect.left + 4, yy), (rect.right - 4, yy), 2)
    pygame.draw.rect(surface, VENT_FRAME, rect, 2)


def draw_star(surface, pos, now, seed):
    r = STAR_RADIUS * (1 + 0.15 * math.sin(now * 4 + seed))
    pts = [(pos[0] + math.cos(-math.pi / 2 + i * math.pi / 5) * (r if i % 2 == 0 else r * 0.45),
            pos[1] + math.sin(-math.pi / 2 + i * math.pi / 5) * (r if i % 2 == 0 else r * 0.45))
           for i in range(10)]
    pygame.draw.polygon(surface, STAR_COLOR, pts)
    pygame.draw.polygon(surface, (255, 250, 170), pts, 1)


def blit_center(surface, img, pos):
    surface.blit(img, img.get_rect(center=pos))


def draw_star_arrow(surface, player_pos, stars, now):
    """Draw an arrow around the player pointing at the nearest star."""
    if not stars:
        return
    target = min((tile_center(s) for s in stars), key=lambda c: player_pos.distance_to(c))
    if player_pos.distance_to(target) < 2 * TILE:  # already close, no hint needed
        return
    direction = (target - player_pos).normalize()
    perp = pygame.Vector2(-direction.y, direction.x)
    pulse = 1 + 0.15 * math.sin(now * 6)
    base = CENTER + direction * ARROW_RADIUS
    tip = CENTER + direction * (ARROW_RADIUS + ARROW_SIZE * 1.8 * pulse)
    pts = [tip, base + perp * ARROW_SIZE, base - direction * ARROW_SIZE * 0.3, base - perp * ARROW_SIZE]
    pygame.draw.polygon(surface, ARROW_COLOR, pts)
    pygame.draw.polygon(surface, (255, 250, 170), pts, 1)


class Maze:
    def __init__(self, rows):
        self.grid = [[0 if ch in ".V" else 1 for ch in row] for row in rows]
        self.width = len(self.grid[0])
        self.height = len(self.grid)
        self.vents = {(x, y) for y, row in enumerate(rows) for x, ch in enumerate(row) if ch == "V"}

    def is_valid(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height and self.grid[int(y)][int(x)] == 0

    def is_wall_pixel(self, px, py):
        return not self.is_valid(int(px // TILE), int(py // TILE))


def compute_maze_distances(target_tile, maze):
    distances = {target_tile: 0}
    queue = deque([target_tile])
    while queue:
        x, y = queue.popleft()
        for dx, dy in DIRS:
            n = (x + dx, y + dy)
            if maze.is_valid(*n) and n not in distances:
                distances[n] = distances[(x, y)] + 1
                queue.append(n)
    return distances


def nearby_walls(rect, grid):
    rows, cols = len(grid), len(grid[0])
    return [pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)
            for ty in range(rect.top // TILE - 1, rect.bottom // TILE + 2)
            for tx in range(rect.left // TILE - 1, rect.right // TILE + 2)
            if 0 <= tx < cols and 0 <= ty < rows and grid[ty][tx] == 1]


def tile_of(pos):
    return (int(pos.x // TILE), int(pos.y // TILE))


def tile_center(tile):
    return pygame.Vector2((tile[0] + 0.5) * TILE, (tile[1] + 0.5) * TILE)


def build_light_polygon(origin, maze):
    pts = []
    for i in range(RAY_COUNT):
        a = 2 * math.pi * i / RAY_COUNT
        dx, dy = math.cos(a), math.sin(a)
        d = 0
        while d < VISION_RADIUS:
            d += RAY_STEP
            if maze.is_wall_pixel(origin.x + dx * d, origin.y + dy * d):
                break
        d = min(d + RAY_STEP, VISION_RADIUS)
        pts.append((WIDTH / 2 + dx * d, HEIGHT / 2 + dy * d))
    return pts


def has_line_of_sight(ax, ay, bx, by, maze):
    steps = max(1, int(math.hypot(bx - ax, by - ay) // RAY_STEP))
    return not any(maze.is_wall_pixel(ax + (bx - ax) * i / steps, ay + (by - ay) * i / steps)
                   for i in range(1, steps))


def find_dig_exit(killer_pos, player_pos, maze):
    kx, ky = killer_pos
    px, py = player_pos
    dist = math.hypot(px - kx, py - ky)
    steps = max(1, int(dist // 2))
    walls, first_wall, exit_tile, inside = set(), None, None, False
    for i in range(steps + 1):
        t = i / steps
        sx, sy = kx + (px - kx) * t, ky + (py - ky) * t
        tile = (int(sx // TILE), int(sy // TILE))
        if maze.is_wall_pixel(sx, sy):
            walls.add(tile)
            if first_wall is None:
                first_wall = t * dist
            inside = True
        else:
            if inside and exit_tile is None:
                exit_tile = tile
            inside = False
    if len(walls) != 1 or exit_tile is None or first_wall > DIG_REACH:
        return None
    path = compute_maze_distances((int(px // TILE), int(py // TILE)), maze).get((int(kx // TILE), int(ky // TILE)))
    if path is not None and path < DIG_MIN_PATH:
        return None
    return tile_center(exit_tile)


class Monster:
    def __init__(self, tile, speed, exact, digs, frames):
        self.x, self.y = tile_center(tile)
        self.base_speed = speed
        self.speed = speed
        self.exact = exact
        self.digs = digs
        self.frames = frames
        self.state = "walk"
        self.state_start = 0.0
        self.exit_pos = None
        self.last_dig_end = 0.0
        self.current_waypoint = None
        self.marks = []
        self.flee_target = None
        self.flee_wait = 0.0
        self.moving = False
        self.flip = False

    @property
    def underground(self):
        return self.state == "tunnel"

    @property
    def digging(self):
        return self.state in ("burrow", "tunnel")

    def set_state(self, state, now):
        self.state = state
        self.state_start = now

    def update(self, player_pos, player_dir, maze, dt, hidden, rush):
        now = time.time()
        ox, oy = self.x, self.y
        self.marks = [m for m in self.marks if now - m[2] < MARK_LIFETIME]
        self.speed = self.base_speed * (RUSH_MULT if rush and not hidden else 1)

        if self.state == "walk":
            if hidden:
                self.flee(player_pos, maze, dt)
            else:
                self.flee_target = None
                self.flee_wait = 0.0
                exit_pos = None
                if self.digs and now - self.last_dig_end >= DIG_COOLDOWN:
                    exit_pos = find_dig_exit((self.x, self.y), (player_pos.x, player_pos.y), maze)
                if exit_pos:
                    self.exit_pos = exit_pos
                    self.current_waypoint = None
                    self.set_state("burrow", now)
                    self.marks.append((self.x, self.y, now))
                else:
                    self.chase(player_pos, player_dir, maze, dt)
        elif self.state == "burrow":
            if now - self.state_start >= BURROW_TIME:
                self.set_state("tunnel", now)
        elif self.state == "tunnel":
            dx, dy = self.exit_pos[0] - self.x, self.exit_pos[1] - self.y
            dist = math.hypot(dx, dy)
            step = KILLER_DIG_SPEED * dt
            if dist <= step:
                self.x, self.y = self.exit_pos
                self.marks.append((self.x, self.y, now))
                self.set_state("emerge", now)
            else:
                self.x += dx / dist * step
                self.y += dy / dist * step
        elif now - self.state_start >= EMERGE_TIME:
            self.last_dig_end = now
            self.current_waypoint = None
            self.set_state("walk", now)

        moved_x = self.x - ox
        self.moving = math.hypot(moved_x, self.y - oy) > 0.05
        if abs(moved_x) > 0.05:
            self.flip = moved_x < 0

    def chase(self, player_pos, player_dir, maze, dt):
        if self.exact:
            self.walk_toward(tile_of(player_pos), maze, dt, player_pos)
            return
        target = tile_of(player_pos + player_dir * 60)
        if not maze.is_valid(*target):
            target = tile_of(player_pos)
        self.walk_toward(target, maze, dt)

    def flee(self, player_pos, maze, dt):
        if self.flee_target is None:
            if self.flee_wait > 0:
                self.flee_wait -= dt
                return
            here = tile_of(pygame.Vector2(self.x, self.y))
            from_monster = compute_maze_distances(here, maze)
            from_player = compute_maze_distances(tile_of(player_pos), maze)
            options = [t for t, d in from_monster.items() if 3 <= d <= 16 and t in from_player]
            if not options:
                return
            self.flee_target = max(options, key=lambda t: (from_player[t], -from_monster[t]))
            self.current_waypoint = None
        if self.walk_toward(self.flee_target, maze, dt):
            self.flee_target = None
            self.flee_wait = 1.0

    def walk_toward(self, target_tile, maze, dt, direct=None):
        here = tile_of(pygame.Vector2(self.x, self.y))
        if here == target_tile:
            self.current_waypoint = None
            goal = direct if direct is not None else tile_center(target_tile)
        else:
            if (self.current_waypoint is None
                    or math.hypot(self.current_waypoint[0] - self.x, self.current_waypoint[1] - self.y) < 3):
                dist_map = compute_maze_distances(target_tile, maze)
                valid = [(here[0] + dx, here[1] + dy) for dx, dy in DIRS if (here[0] + dx, here[1] + dy) in dist_map]
                if not valid:
                    self.current_waypoint = None
                    return False
                self.current_waypoint = tile_center(min(valid, key=lambda n: dist_map[n]))
            goal = self.current_waypoint
        dx, dy = goal[0] - self.x, goal[1] - self.y
        dist = math.hypot(dx, dy)
        if dist > 1:
            step = min(self.speed * dt, dist)
            self.x += dx / dist * step
            self.y += dy / dist * step
        return here == target_tile and dist <= 3

    def draw(self, surface, now, cam):
        pos = (int(self.x - cam.x), int(self.y - cam.y))
        img = self.frames[int(now * ANIM_FPS) % len(self.frames)] if self.moving else self.frames[0]
        if self.flip:
            img = pygame.transform.flip(img, True, False)
        if self.state == "walk":
            blit_center(surface, img, pos)
        elif self.state == "tunnel":
            pygame.draw.circle(surface, DIRT_DARK, pos, 16)
            pygame.draw.circle(surface, DIRT, pos, 12)
        else:
            burrowing = self.state == "burrow"
            p = min(1.0, (now - self.state_start) / (BURROW_TIME if burrowing else EMERGE_TIME))
            k = 1 - p if burrowing else p
            pygame.draw.circle(surface, DIRT, pos, int(10 + 12 * (p if burrowing else 1 - p)))
            if k > 0.05:
                blit_center(surface, pygame.transform.scale(img, (max(1, int(img.get_width() * k)),
                                                                  max(1, int(img.get_height() * k)))), pos)


def draw_marks(surface, monster, player_pos, maze, now, cam):
    for mx, my, created in monster.marks:
        if math.hypot(mx - player_pos.x, my - player_pos.y) > VISION_RADIUS:
            continue
        if not has_line_of_sight(player_pos.x, player_pos.y, mx, my, maze):
            continue
        fade = 1 - (now - created) / MARK_LIFETIME
        pos = (int(mx - cam.x), int(my - cam.y))
        pygame.draw.circle(surface, tuple(int(c * fade) for c in DIRT), pos, 21)
        pygame.draw.circle(surface, tuple(int(c * fade) for c in DIRT_DARK), pos, 21, 2)


def move_player(pos, rect, move, maze):
    pos.x += move.x
    rect.center = (round(pos.x), round(pos.y))
    for wall in nearby_walls(rect, maze.grid):
        if rect.colliderect(wall):
            if move.x > 0:
                rect.right = wall.left
            elif move.x < 0:
                rect.left = wall.right
            pos.x = rect.centerx
    pos.y += move.y
    rect.center = (round(pos.x), round(pos.y))
    for wall in nearby_walls(rect, maze.grid):
        if rect.colliderect(wall):
            if move.y > 0:
                rect.bottom = wall.top
            elif move.y < 0:
                rect.top = wall.bottom
            pos.y = rect.centery


class Game:
    def __init__(self, best=0):
        self.maze = Maze(MAP)
        self.open_tiles = [(x, y) for y in range(self.maze.height) for x in range(self.maze.width)
                           if self.maze.is_valid(x, y)]
        # Monster A starts nearest the map center, monster B nearest the bottom-right corner
        a_tile = min(self.open_tiles, key=lambda t: math.hypot(t[0] - (self.maze.width - 1) / 2,
                                                              t[1] - (self.maze.height - 1) / 2))
        b_tile = min(self.open_tiles, key=lambda t: math.hypot(t[0] - (self.maze.width - 2),
                                                              t[1] - (self.maze.height - 2)))
        self.a = Monster(a_tile, MONSTER_A_SPEED, True, False, MONSTER_A_FRAMES)
        self.b = Monster(b_tile, MONSTER_B_SPEED, False, True, MONSTER_B_FRAMES)
        self.monsters = [self.a, self.b]
        self.rush = False
        self.score = 0
        self.best = best
        self.hidden = False
        self.dir = pygame.Vector2()
        self.angle = 0.0
        self.moving = False
        self.close_on = False
        self.stars = []
        self.respawn(START_GRACE)
        while len(self.stars) < STAR_COUNT:
            self.add_star()

    def respawn(self, grace):
        safe = [t for t in self.open_tiles
                if all(math.hypot(tile_center(t).x - m.x, tile_center(t).y - m.y) >= SAFE_RESPAWN for m in self.monsters)]
        self.pos = tile_center(random.choice(safe or self.open_tiles))
        self.hidden = False
        self.dir = pygame.Vector2()
        self.rush = False
        self.grace = grace
        self.stars = [s for s in self.stars if math.hypot(s[0] * TILE + TILE / 2 - self.pos.x,
                                                          s[1] * TILE + TILE / 2 - self.pos.y) > COLLECT_DISTANCE]
        while len(self.stars) < STAR_COUNT:
            self.add_star()

    def add_star(self):
        for _ in range(60):
            t = random.choice(self.open_tiles)
            if t not in self.stars and math.hypot(tile_center(t).x - self.pos.x, tile_center(t).y - self.pos.y) > 4 * TILE:
                self.stars.append(t)
                return
        self.stars.append(random.choice(self.open_tiles))

    def die(self):
        self.best = max(self.best, self.score)
        self.score = 0
        self.stop_loops(150)
        play_sound(SND_RESPAWN)
        self.respawn(RESPAWN_GRACE)

    def stop_loops(self, fade_ms=300):
        self.close_on = False
        stop_loop(CH_CLOSE, fade_ms)

    def toggle_hide(self):
        if self.hidden:
            self.hidden = False
            play_sound(SND_VENT)
        elif tile_of(self.pos) in self.maze.vents:
            self.hidden = True
            self.pos = tile_center(tile_of(self.pos))
            self.dir = pygame.Vector2()
            play_sound(SND_VENT)

    def update(self, dt, mouse_pos):
        rect = pygame.Rect(0, 0, PLAYER_SIZE, PLAYER_SIZE)
        self.moving = False
        if self.hidden:
            self.pos = tile_center(tile_of(self.pos))
            rect.center = (round(self.pos.x), round(self.pos.y))
        else:
            offset = pygame.Vector2(mouse_pos) - CENTER
            if offset.length() > 2:
                self.dir = offset.normalize()
                target = math.degrees(math.atan2(-self.dir.y, self.dir.x)) + 90
                self.angle += ((target - self.angle + 180) % 360 - 180) * min(1.0, 14 * dt)
            move = offset * FOLLOW_SPEED * dt
            if move.length() > MAX_SPEED * dt:
                move.scale_to_length(MAX_SPEED * dt)
            before = self.pos.copy()
            move_player(self.pos, rect, move, self.maze)
            self.moving = (self.pos - before).length() > 0.1

        if self.grace > 0:
            self.grace -= dt
        else:
            self.update_monsters(dt)
            for m in self.monsters:
                if (not m.underground and not self.hidden
                        and math.hypot(self.pos.x - m.x, self.pos.y - m.y) < CATCH_DISTANCE):
                    self.die()
                    return

        if not self.hidden:
            for s in list(self.stars):
                if math.hypot(s[0] * TILE + TILE / 2 - self.pos.x, s[1] * TILE + TILE / 2 - self.pos.y) < COLLECT_DISTANCE:
                    self.stars.remove(s)
                    play_sound(SND_STAR)
                    self.score += 1
                    self.best = max(self.best, self.score)
                    self.add_star()

        self.update_audio()

    def update_audio(self):
        # The monster-close sound plays while a monster is in view (same test used to draw it)
        in_view = [math.hypot(m.x - self.pos.x, m.y - self.pos.y) for m in self.monsters
                   if not m.underground
                   and math.hypot(m.x - self.pos.x, m.y - self.pos.y) <= VISION_RADIUS
                   and has_line_of_sight(self.pos.x, self.pos.y, m.x, m.y, self.maze)]
        if in_view:
            volume = CLOSE_MIN_VOL + (1 - CLOSE_MIN_VOL) * (1 - min(in_view) / VISION_RADIUS)
            if not self.close_on:
                self.close_on = True
                start_loop(CH_CLOSE, SND_CLOSE, volume, 0)
            else:
                set_loop_volume(CH_CLOSE, volume)
        elif self.close_on:
            self.close_on = False
            stop_loop(CH_CLOSE, 120)

    def update_monsters(self, dt):
        dist_map = compute_maze_distances(tile_of(self.pos), self.maze)
        da, db = dist_map.get(tile_of(self.a)), dist_map.get(tile_of(self.b))
        if da is not None and db is not None:
            if not self.rush and db > da:
                self.rush = True
            elif self.rush and db < RUSH_END_RATIO * da:
                self.rush = False
        for m in self.monsters:
            m.update(self.pos, self.dir, self.maze, dt, self.hidden, self.rush if m is self.b else False)

    def draw(self, now):
        cam = self.pos - CENTER
        world.fill((0, 0, 0))
        reach = VISION_RADIUS // TILE + 2
        ptx, pty = tile_of(self.pos)
        for ty in range(max(0, pty - reach), min(self.maze.height, pty + reach + 1)):
            for tx in range(max(0, ptx - reach), min(self.maze.width, ptx + reach + 1)):
                pos = (tx * TILE - cam.x, ty * TILE - cam.y)
                if self.maze.grid[ty][tx] == 1:
                    world.blit(wall_img, pos)
                else:
                    pygame.draw.rect(world, FLOOR, (*pos, TILE, TILE))
                    if (tx, ty) in self.maze.vents:
                        draw_vent(world, pos[0], pos[1])

        for i, s in enumerate(self.stars):
            draw_star(world, ((s[0] + 0.5) * TILE - cam.x, (s[1] + 0.5) * TILE - cam.y), now, i)

        for m in self.monsters:
            draw_marks(world, m, self.pos, self.maze, now, cam)
        for m in self.monsters:
            if (math.hypot(m.x - self.pos.x, m.y - self.pos.y) <= VISION_RADIUS
                    and has_line_of_sight(self.pos.x, self.pos.y, m.x, m.y, self.maze)):
                m.draw(world, now, cam)

        img = PLAYER_FRAMES[int(now * ANIM_FPS) % len(PLAYER_FRAMES)] if self.moving else PLAYER_FRAMES[0]
        img = pygame.transform.rotate(img, self.angle)
        if self.hidden:
            img.set_alpha(110)
        blit_center(world, img, (WIDTH // 2, HEIGHT // 2))

        world.blit(light_falloff, (WIDTH // 2 - VISION_RADIUS - 1, HEIGHT // 2 - VISION_RADIUS - 1))
        darkness.fill((0, 0, 0))
        pygame.draw.polygon(darkness, (255, 0, 255), build_light_polygon(self.pos, self.maze))
        world.blit(darkness, (0, 0))

        awake = self.grace <= 0 and not self.hidden
        nearest = min((math.hypot(m.x - self.pos.x, m.y - self.pos.y) for m in self.monsters if not m.underground),
                      default=1e9)
        if awake and nearest < DANGER_RANGE:
            closeness = 1 - nearest / DANGER_RANGE
            pulse = 0.55 + 0.45 * math.sin(now * (6 + 8 * closeness))
            danger_vignette.set_alpha(int(255 * closeness * pulse))
            world.blit(danger_vignette, (0, 0))

        shake_x = shake_y = 0
        if self.grace <= 0:
            for m in self.monsters:
                d = math.hypot(m.x - self.pos.x, m.y - self.pos.y)
                if m.digging and d < SHAKE_RANGE:
                    power = MAX_SHAKE * (1 - d / SHAKE_RANGE)
                    shake_x = random.uniform(-power, power)
                    shake_y = random.uniform(-power, power)

        screen.fill((0, 0, 0))
        screen.blit(world, (shake_x, shake_y))
        if not self.hidden:
            draw_star_arrow(screen, self.pos, self.stars, now)
        screen.blit(font.render(f"Stars: {self.score}", True, STAR_COLOR), (10, 10))
        screen.blit(font.render(f"Best: {self.best}", True, (255, 255, 255)), (10, 40))
        if self.rush and awake:
            screen.blit(font.render("RUSH!", True, (255, 80, 80)), (10, 70))

        if self.hidden:
            text, color = "HIDDEN - press E to come out", (120, 200, 255)
        elif tile_of(self.pos) in self.maze.vents:
            text, color = "Press E to hide in the vent", (255, 255, 255)
        else:
            text, color = "SPACE - menu", (120, 120, 120)
        hint = font.render(text, True, color)
        screen.blit(hint, hint.get_rect(midbottom=(WIDTH // 2, HEIGHT - 20)))


def draw_menu(now, best, mouse, play_btn, quit_btn):
    screen.fill((8, 8, 12))
    title = title_font.render("MAZE HORROR", True, RED)
    screen.blit(title, title.get_rect(center=(WIDTH // 2, 130)))
    sub = font.render("Collect stars. Don't get caught.", True, (180, 180, 180))
    screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 200)))

    idx = int(now * ANIM_FPS) % 4
    hero = pygame.transform.scale_by(PLAYER_FRAMES[idx], 3)
    mon_a = pygame.transform.scale_by(MONSTER_A_FRAMES[idx], 3)
    mon_b = pygame.transform.scale_by(MONSTER_B_FRAMES[idx], 3)
    blit_center(screen, mon_a, (WIDTH // 2 - 280, 330))
    blit_center(screen, hero, (WIDTH // 2, 330))
    blit_center(screen, pygame.transform.flip(mon_b, True, False), (WIDTH // 2 + 280, 330))

    buttons = ((play_btn, "PLAY"),) if IS_WEB else ((play_btn, "PLAY"), (quit_btn, "QUIT"))
    for rect, label in buttons:
        hover = rect.collidepoint(mouse)
        pygame.draw.rect(screen, (70, 20, 20) if hover else (35, 35, 40), rect, border_radius=8)
        pygame.draw.rect(screen, RED if hover else (110, 110, 120), rect, 2, border_radius=8)
        text = big_font.render(label, True, (255, 255, 255))
        screen.blit(text, text.get_rect(center=rect.center))

    best_text = font.render(f"Best score: {best}", True, STAR_COLOR)
    screen.blit(best_text, best_text.get_rect(center=(WIDTH // 2, 600)))
    help_text = font.render("Mouse: move   E: hide in vents   SPACE: back to menu   ENTER: play", True, (130, 130, 130))
    screen.blit(help_text, help_text.get_rect(center=(WIDTH // 2, 650)))


async def main():
    play_btn = pygame.Rect(WIDTH // 2 - 130, 430, 260, 64)
    quit_btn = pygame.Rect(WIDTH // 2 - 130, 515, 260, 64)
    state = "menu"
    game = None
    best = 0
    running = True
    while running:
        dt = clock.tick(FPS) / 1000
        now = time.time()
        mouse = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif state == "menu":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if play_btn.collidepoint(event.pos):
                        game, state = Game(best), "playing"
                    elif not IS_WEB and quit_btn.collidepoint(event.pos):
                        running = False
                elif event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    game, state = Game(best), "playing"
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    best = max(best, game.best, game.score)
                    game.stop_loops(200)
                    state = "menu"
                elif event.key == pygame.K_e:
                    game.toggle_hide()

        if state == "menu":
            draw_menu(now, best, mouse, play_btn, quit_btn)
        else:
            game.update(dt, mouse)
            game.draw(now)
        pygame.display.flip()
        await asyncio.sleep(0)   # hand control back to the browser each frame

    pygame.quit()


asyncio.run(main())